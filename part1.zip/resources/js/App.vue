<template>
  <div class="container">
    <nav class="navbar navbar-expand-sm bg-dark navbar-dark fixed" v-show="$route.name !== 'login' && $route.name !== 'login2'" >
      <ul class="navbar-nav">
        <li class="nav-item">
         <router-link :to="{ name: 'home' }">Home</router-link>
        </li>
        <li class="nav-item">
          <router-link to="/create" class="nav-link">Create Spot</router-link>
        </li>
        <li class="nav-item">
          <router-link to="/posts" class="nav-link">Spots</router-link>
        </li>
         <li class="nav-item">
          <router-link to="/register" class="nav-link">Register Admin</router-link>
        </li>
        <li class="nav-item">
          <a href="#" @click.prevent="$auth.logout()">Logout</a>
        </li>
      </ul>
    </nav>
    <transition name="fade">
      <router-view></router-view>
    </transition>
  </div>
</template>

<style>
    body{
        background-color: black;
    }
    .fade-enter-active, .fade-leave-active {
      transition: opacity .5s
    }
    .fade-enter, .fade-leave-active {
      opacity: 0
    }
</style>

<script>
    export default{

    }
</script>