<template>
 <form class="container" @submit.prevent="updatePost">
    <div id="upd_err"></div>
    <div class="row">
        <div class="form-group label col-sm">
            <label>Spot</label>
            <input type="name" class="form-control" name="spotName2" v-model="post.spotName">
        </div>
    </div>
    <div class="row">
        <div class="form-group label col-sm">
            <label>Region</label>
            <select class="form-control" name="region2" v-model="post.region">
                <option value="goldCoast">Gold Coast</option>
            </select>
        </div>
    </div>
    <div class="row">
        <div class="form-group label col-sm">
            <label>perfect wind direction </label>
            <select class="form-control" name="windDirection2" v-model="post.windDirection">
                <option value="180">S</option>
                <option value="157.5">SSE</option>
                <option value="135">SE</option>
                <option value="112.5">ESE</option>
                <option value="90">E</option>
                <option value="67.5">ENE</option>
                <option value="45">NE</option>
                <option value="22.5">NNE</option>
                <option value="0.1">N</option>
                <option value="337.5">NNW</option>
                <option value="315">NW</option>
                <option value="292.5">WNW</option>
                <option value="270">W</option>
                <option value="247.5">WSW</option>
                <option value="225">SW</option>
                <option value="202.5">SSW</option>
            </select>
        </div>
    </div>
    <div class="row">
        <div class="form-group label col-sm">
            <label>perfect direction of swell</label>
            <select class="form-control" name="swellDirection2" v-model="post.swellDirection">
                <option value="180">S</option>
                <option value="157.5">SSE</option>
                <option value="135">SE</option>
                <option value="112.5">ESE</option>
                <option value="90">E</option>
                <option value="67.5">ENE</option>
                <option value="45">NE</option>
                <option value="22.5">NNE</option>
                <option value="0.1">N</option>
                <option value="337.5">NNW</option>
                <option value="315">NW</option>
                <option value="292.5">WNW</option>
                <option value="270">W</option>
                <option value="247.5">WSW</option>
                <option value="225">SW</option>
                <option value="202.5">SSW</option>
            </select>
        </div>
    </div>
    <div class="row">
        <div class="form-group label col-sm">
            <label>min swell to breaking (ft)</label>
            <input type="number" class="form-control" name="swellSize2" v-model="post.swellSize">
        </div>
    </div>
    <div class="row">
        <div class="form-group label col-sm">
            <label>tide height (m)</label>
            <input type="number"  step="0.01" class="form-control" name="tide2" v-model="post.tide">
        </div>
    </div>
    <div class="row">
        <div class="col-xs mx-auto">
            <button class="btn btn-primary submit logoP col-sm mx-auto">Update</button>
        </div>             
    </div>  
  </form>
</template>

<script>
    export default {

      data() {
        return {
          post: {}
        }
      },
      created() {
        let uri = `http://localhost:8000/api/post/edit/${this.$route.params.id}`;
        this.axios.get(uri).then((response) => {
            this.post = response.data;
        });
      },
      methods: {
        updatePost() {
          let uri = `http://localhost:8000/api/post/update/${this.$route.params.id}`;
          this.axios.post(uri, this.post).then((response) => {
            if(response.data == 'spotName Exists Already'){
              document.getElementById('upd_err').style.display = 'block';
              document.getElementById('upd_err').innerHTML = 'Spot already in database';
          }
          else if(response.data == 'emptyValues'){
            document.getElementById('upd_err').style.display = 'block';
            document.getElementById('upd_err').innerHTML = 'Please no empty values';
          }
          else{
            document.getElementById('upd_err').style.display = 'none';
            this.$router.push({name: 'posts'});
          }
          });
        }
      }
    }
</script>

<style scoped>
@import url(http://fonts.googleapis.com/css?family=Norican);
.logoP{
    text-align: center;
    font-family: 'Norican', cursive;
}
.label{
    font-size: 24px;
   color: #41D1E2;
    font-family: 'Bookman';
    margin-left: 20px;
    margin-right: 20px;
}
.submit{
    height: 36px;
    font-size: 18px;
    background-color: black;
    border: 1px solid white;
    color: white;
    width: 90px;
    margin-top: 20px;
    margin-bottom: 20px;
    padding: 5px;
}
#upd_err{
    font-size: 20px;
    color: red;
    font-family: 'Norican', cursive;
    margin-left: 40px;
    margin-bottom: 10px;
    margin-top: 20px;
    display: none;
}
</style>