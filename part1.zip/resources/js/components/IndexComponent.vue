<template>
  <div class="container">
    <div v-for="post in posts" :key="post.id">
      <div class="row">
          <div class="form-group label col-sm">
              <label class="updSpot">Spot</label>
              <input type="name" class="form-control" v-model="post.spotName" readonly>
          </div>
      </div>
      <div class="row">
          <div class="col-xs-4 mx-auto">
              <p class="blue3 logoP">Swell (°/m)</p>
              <div class="d-flex">
                  <input type="name" class="currentInp" v-model="post.swellDirection" readonly>
              </div>
              <div class="d-flex">
                  <input type="number" class="currentInp" v-model="post.swellSize" readonly>
              </div>
          </div>
          <div class="col-xs-4 mx-auto">
              <p class="blue3 logoP">Wind (°)</p>
              <div class="d-flex">
                  <input type="name" class="currentInp" v-model="post.windDirection" readonly>
              </div>
          </div>
          <div class="col-xs-4 mx-auto">
              <p class="blue3 logoP">Tide (m)</p>
              <div class="d-flex">
                  <input type="number" class="currentInp" v-model="post.tide" readonly>
              </div>
          </div>
      </div>
      <div class="row">
          <div class="col-xs mx-auto">
              <button type="button" class="btn btn-primary submit logoP col-sm mx-auto"><router-link :to="{name: 'edit', params: { id: post.id }}">Edit</router-link></button>
          </div> 
          <div class="col-xs mx-auto">
              <button class="btn btn-primary submit logoP col-sm mx-auto" @click.prevent="deletePost(post.id)">Delete</button>
          </div>                 
      </div> 
    </div>
  </div>       
</template>

<script>
  export default {
      data() {
        return {
          posts: []
        }
      },
      created() {
      let uri = 'http://localhost:8000/api/posts';
      this.axios.get(uri).then(response => {
        this.posts = response.data.data;
      });
    },
    methods: {
      deletePost(id)
      {
        let uri = `http://localhost:8000/api/post/delete/${id}`;
        this.axios.delete(uri).then(response => {
          this.posts.splice(this.posts.indexOf(id), 1);
        });
      }
    }
  }
</script>

<style scoped>
@import url(http://fonts.googleapis.com/css?family=Norican);
.logoP{
    text-align: center;
    font-family: 'Norican', cursive;
}
.label{
    font-size: 24px;
   color: #41D1E2;
    font-family: 'Bookman';
    margin-left: 20px;
    margin-right: 20px;
}
.submit{
    height: 36px;
    font-size: 18px;
    background-color: black;
    border: 1px solid white;
    color: white;
    width: 90px;
    margin-top: 20px;
    margin-bottom: 20px;
    padding: 5px;
}
.updSpot{
    border-top: 3px solid white;
    width: 90%;
    margin-top: 15px; 
}
.blue3{
    color: #41D1E2;
    font-size: 20px;
    height: 10px;
    margin-bottom: 10px;
}
.currentInp{
    background-color: black;
    color: white;
    width: 80px;
    margin-top: 10px;
    border: none;
    margin-right: -5px;
    font-size: 18px;
    text-align: center;
}
</style>