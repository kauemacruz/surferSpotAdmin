<template>
 <div>
    <div class="container loginHead">
      <div class="row">
          <div class="mx-auto logo">
            <svg class="img-fluid" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" style="isolation:isolate" viewBox="543.5 263 161 99" width="161pt" height="99pt"><defs>
            <clipPath id="_clipPath_g0XRYpNbysfUHztiHC9APot7oS2KROmP"><rect x="543.5" y="263" width="161" height="99"/></clipPath></defs><g clip-path="url(#_clipPath_g0XRYpNbysfUHztiHC9APot7oS2KROmP)"><g style="isolation:isolate"/>
            <defs><filter id="X92yhNFltpIiVVMBIkuTcOOukLe3qual" x="-200%" y="-200%" width="400%" height="400%" filterUnits="objectBoundingBox" color-interpolation-filters="sRGB"><feOffset xmlns="http://www.w3.org/2000/svg" in="SourceGraphic" dx="-5" dy="-5"/>
            <feGaussianBlur xmlns="http://www.w3.org/2000/svg" stdDeviation="6.440413594258542" result="pf_100_offsetBlur"/><feComposite xmlns="http://www.w3.org/2000/svg" in="SourceGraphic" in2="pf_100_offsetBlur" result="pf_100_inverse" operator="out"/>
            <feFlood xmlns="http://www.w3.org/2000/svg" flood-color="#000000" flood-opacity="0.5" result="pf_100_color"/><feComposite xmlns="http://www.w3.org/2000/svg" in="pf_100_color" in2="pf_100_inverse" operator="in" result="pf_100_shadow"/>
            <feComposite xmlns="http://www.w3.org/2000/svg" in="pf_100_shadow" in2="SourceGraphic" operator="over"/></filter></defs><g filter="url(#X92yhNFltpIiVVMBIkuTcOOukLe3qual)"><path d=" M 680 263.425 Q 626.63 260.44 591.488 278.425 Q 556.347 296.41 543.5 325.425 Q 566.049 344.458 588.289 342.425 C 610.24 340.419 626.149 330.547 634.145 315.425 Q 584.654 319.531 600.02 294.425 Q 615.543 269.06 680 263.425 Z " fill="rgb(65,209,226)"/>
            </g><defs><filter id="91Q8VdFItZWcaIXuKxkYETf2zwdGAUcD" x="-200%" y="-200%" width="400%" height="400%" filterUnits="objectBoundingBox" color-interpolation-filters="sRGB"><feOffset xmlns="http://www.w3.org/2000/svg" in="SourceGraphic" dx="5" dy="5"/><feGaussianBlur xmlns="http://www.w3.org/2000/svg" stdDeviation="8.587218125678056" result="pf_100_offsetBlur"/><feComposite xmlns="http://www.w3.org/2000/svg" in="SourceGraphic" in2="pf_100_offsetBlur" result="pf_100_inverse" operator="out"/>
            <feFlood xmlns="http://www.w3.org/2000/svg" flood-color="#000000" flood-opacity="0.5" result="pf_100_color"/><feComposite xmlns="http://www.w3.org/2000/svg" in="pf_100_color" in2="pf_100_inverse" operator="in" result="pf_100_shadow"/><feComposite xmlns="http://www.w3.org/2000/svg" in="pf_100_shadow" in2="SourceGraphic" operator="over"/></filter></defs><g filter="url(#91Q8VdFItZWcaIXuKxkYETf2zwdGAUcD)"><path d=" M 699.761 279 Q 685.478 270.993 633.368 291 C 606.682 301.246 629.733 307.403 642.221 303 C 657.741 297.528 671.984 307.818 655.499 326 C 638.77 344.451 636.338 343.266 588 362 Q 654.015 360.811 679.843 331 Q 715.31 290.065 699.761 279 Z " fill="rgb(0,255,0)"/></g></g>
            </svg>
          </div> 
      </div>   
      <div class="row">
          <div class="col-sm">
              <p class="logoP green">Surfer'Spot</p>
          </div> 
      </div>   
      <div class="row">
          <div class="col-sm">
              <p class="logoP blue">the perfect beach today</p>
          </div> 
      </div>    
    </div>
    <form autocomplete="off" @submit.prevent="login" method="post" class="container">
        <div id="log_err"></div>
        <p v-if="errors.length">
            <b>Please correct the following error(s):</b>
            <ul>
                <li v-for='error in errors' :key='error'>{{ error }}</li>
            </ul>
        </p>

        <div class="row">
            <div class="form-group label col-sm">
                <label for="email">Email address</label>
                <input type="email" id="email" class="form-control" placeholder="user@example.com" v-model="email" >
            </div>
        </div>
        <div class="row">
            <div class="form-group label col-sm">
                <label for="password">Password</label>
                <input type="password" id="password" class="form-control" v-model="password" >
            </div>
        </div>
        <div class="row">
            <div class="col-xs mx-auto">
                <button class="btn btn-primary submit logoP col-sm mx-auto" type="submit">Login</button>
            </div>         
        </div>    
    </form>
  </div>
</template>

<script>
  export default {
    data(){
      return {
        email: null,
        password: null,
        errors: [],
      }
    },
    methods: {
      login(){
        var app = this
        this.$auth.login({
            params: {
              email: app.email,
              password: app.password
            }, 
            success: function () {
              document.getElementById('log_err').style.display = 'none';
            },
            error: function () {
                if (this.email && this.password) {
                    document.getElementById('log_err').style.display = 'block';
                    document.getElementById('log_err').innerHTML = 'Email or password is incorrect';
                }
                this.errors = [];

                if (!this.email) {
                    this.errors.push('Email required.');
                }
                if (!this.password) {
                    this.errors.push('Password required.');
                }       
            },
            rememberMe: true,
            redirect: '/home',
            fetchUser: true,
        });       
      },
    }
  } 
</script>

<style scoped>
@import url(http://fonts.googleapis.com/css?family=Norican);
.logoP{
    text-align: center;
    font-family: 'Norican', cursive;
}
.green{
    color:#00FF00;
    font-size: 33px;
    height: 33px;
}
.blue{
    color: #41D1E2;
    font-size: 24px;
    height: 24px;
}
.logo{
    width: 40%;
    margin-top: 15px;
}
.label{
    font-size: 24px;
   color: #41D1E2;
    font-family: 'Bookman';
    margin-left: 20px;
    margin-right: 20px;
}
.submit{
    height: 36px;
    font-size: 18px;
    background-color: black;
    border: 1px solid white;
    color: white;
    width: 90px;
    margin-top: 20px;
    margin-bottom: 20px;
    padding: 5px;
}
.logo2{
    width: 25%;
    margin-left: 20px;
}
.green2{
    color:#00FF00;
    font-size: 20px;
    width: 100%;
}
.green4{
    color:#00FF00;
    font-size: 16px;
    width: 100%;
}
.blue2{
    color: #41D1E2;
    font-size: 20px;
    width: 100%;
}
.loginHead{
    margin-bottom: 30px;
    margin-top: 30px;
}
#log_err{
    font-size: 20px;
    color: red;
    font-family: 'Norican', cursive;
    margin-left: 40px;
    margin-bottom: 10px;
    margin-top: -20px;
    display: none;
}
</style>