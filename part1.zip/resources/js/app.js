require('./bootstrap');

import Vue from 'vue';

Vue.config.devtools = false;

import VueRouter from 'vue-router';
Vue.use(VueRouter);

import BootstrapVue from 'bootstrap-vue';
Vue.use(BootstrapVue);

import VueAxios from 'vue-axios';
import axios from 'axios';

import App from './App.vue';
Vue.use(VueAxios, axios);
axios.defaults.baseURL = 'http://localhost:8000/api';

import HomeComponent from './components/HomeComponent.vue';
import CreateComponent from './components/CreateComponent.vue';
import IndexComponent from './components/IndexComponent.vue';
import EditComponent from './components/EditComponent.vue';
import Login from './components/Login';
import Register from './components/Register';

const routes = [
    {
        name: 'home',
        path: '/home',
        component: HomeComponent,
        meta: {
            auth: true
        }
    },
    {
        name: 'create',
        path: '/create',
        component: CreateComponent,
        meta: {
            auth: true
        }
    },
    {
        name: 'posts',
        path: '/posts',
        component: IndexComponent,
        meta: {
            auth: true
        }
    },
    {
        name: 'login',
        path: '/login',
        component: Login,

        meta: {
            auth: false
        }
    },
    {
        name: 'login2',
        path: '/',
        component: Login,

        meta: {
            auth: false
        }
    },
    {
        path: '/register',
        name: 'register',
        component: Register,
        meta: {
            auth: true
        }
    },
    {
        name: 'edit',
        path: '/edit/:id',
        component: EditComponent
    }
];
const router = new VueRouter({ mode: 'history', routes: routes});

Vue.router = router

Vue.use(require('@websanova/vue-auth'), {
   auth: require('@websanova/vue-auth/drivers/auth/bearer.js'),
   http: require('@websanova/vue-auth/drivers/http/axios.1.x.js'),
   router: require('@websanova/vue-auth/drivers/router/vue-router.2.x.js'),
});

const app = new Vue(Vue.util.extend({ router }, App)).$mount('#app');