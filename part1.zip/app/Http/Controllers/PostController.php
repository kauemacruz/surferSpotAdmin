<?php

// PostController.php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Resources\PostCollection;
use App\Post;

class PostController extends Controller
{
    public function store(Request $request)
    {
      $spotName = $request->get('spotName');
      $region = $request->get('region');
      $windDirection = $request->get('windDirection');
      $swellDirection = $request->get('swellDirection');
      $swellSize = $request->get('swellSize');
      $tide = $request->get('tide');

      if(empty($spotName) || empty($region) || empty($windDirection) || empty($swellDirection) || empty($swellSize) || empty($tide)){
        return response()->json('emptyValues'); 
      }
      else{
        if(Post::where('spotName', $spotName)->doesntExist()){
        $post = new Post([
          'spotName' => $spotName,
          'region' => $region,
          'swellDirection' => $swellDirection,
          'windDirection' => $windDirection,
          'swellSize' => $swellSize,
          'tide' => $tide
        ]);

        $post->save();

        return response()->json('successfully added');
        }
        else{
          return response()->json('spotName Exists Already');
        }
      }
    }

    public function index()
    {
      return new PostCollection(Post::all());
    }

    public function edit($id)
    {
      $post = Post::find($id);
      return response()->json($post);
    }

    public function update($id, Request $request)
    { 
      $post = Post::find($id);

      $post->update($request->all());

      return response()->json('successfully updated');
    }

    public function delete($id)
    {
      $post = Post::find($id);

      $post->delete();

      return response()->json('successfully deleted');
    }
}