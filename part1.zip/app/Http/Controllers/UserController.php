<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Resources\PostCollection;
use App\User;
use Illuminate\Support\Facades\DB;

class UserController extends Controller
{
    public function login($email, $pass)
    {   
        if(User::where('email', $email)->doesntExist()){
            return response()->json('email not Ok');
        }
        else{
            $result = DB::table('users')->where('email', $email)->value('password');
            if($result !== $pass){
                return response()->json('pass not Ok');
            }
            else{
                return response()->json('pass Ok');
            }
        }
    }
}
