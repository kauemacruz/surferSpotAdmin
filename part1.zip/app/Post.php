<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Post extends Model
{
    protected $fillable = ['spotName', 'region', 'windDirection', 'swellDirection', 'swellSize', 'tide'];
}