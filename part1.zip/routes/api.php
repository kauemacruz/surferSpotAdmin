<?php

use Illuminate\Http\Request;

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});

Route::middleware(['checkIp'])->group(function () {
  Route::post('/post/create', 'PostController@store');
  Route::get('/post/edit/{id}', 'PostController@edit');
  Route::post('/post/update/{id}', 'PostController@update');
  Route::delete('/post/delete/{id}', 'PostController@delete');
  Route::get('/posts', 'PostController@index');
  Route::get('/login/{email}/{password}', 'UserController@login');
  Route::post('auth/register', 'AuthController@register');
  Route::post('auth/login', 'AuthController@login');
});
Route::group(['middleware' => 'jwt.auth'], function(){
  Route::get('auth/user', 'AuthController@user');
});
Route::group(['middleware' => 'jwt.refresh'], function(){
  Route::get('auth/refresh', 'AuthController@refresh');
  Route::post('auth/logout', 'AuthController@logout');
});
