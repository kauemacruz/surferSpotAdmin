For testing this application, please follow the following steps:

Make sure your server is running (i am using wamp server)

you will need to import the database provided called vuecrud

Open two command prompt screens:
In the first, find the path of this folder and type 'npm run watch' and let it running

For the second one type 'php artisan serve' also let it running

if there is any error that is because you probably are missing some installation in your pc.

If everything is fine, you will be able to test the application in the url 'localhost:8000'

For accessing the application, use:

EMAIL: kaue@macruz
PASSWORD: kaue123 

now u will be able to register new users, add new spots, delete and update
