# @babel/plugin-syntax-object-rest-spread

> Allow parsing of object rest/spread

See our website [@babel/plugin-syntax-object-rest-spread](https://babeljs.io/docs/en/next/babel-plugin-syntax-object-rest-spread.html) for more information.

## Install

Using npm:

```sh
npm install --save-dev @babel/plugin-syntax-object-rest-spread
```

or using yarn:

```sh
yarn add @babel/plugin-syntax-object-rest-spread --dev
```
