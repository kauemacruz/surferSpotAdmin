<template>
    <div>
        <div class="text-center">
            <router-link :to="{name: 'index'}">Home</router-link> |
            <router-link :to="{name: 'login'}">Login</router-link>
        </div>

        <h1 />

        <nuxt/>
    </div>
</template>