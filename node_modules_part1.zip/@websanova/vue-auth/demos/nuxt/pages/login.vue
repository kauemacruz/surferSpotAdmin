<template>
    <div>
        Login
    </div>
</template>

<script>
    export default {

        testingAuth: {
            auth: true
        }

    }
</script>