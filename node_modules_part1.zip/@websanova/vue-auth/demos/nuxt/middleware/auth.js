export default function (ctx) {

    // console.log(this);
    // console.log(ctx.options);

    console.log(ctx);
    // console.log(ctx.app);
  
    // if (route.name === 'index') {
    //     return redirect('/login');
    // }

    // console.log(route);

    return;
}