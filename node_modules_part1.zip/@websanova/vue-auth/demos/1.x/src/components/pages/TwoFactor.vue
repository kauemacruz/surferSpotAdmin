<template>
    <div>
        <h1>TwoFactor</h1>

        Not complete (and no plan yet) but would be cool to get this in eventually.
    </div>
</template>