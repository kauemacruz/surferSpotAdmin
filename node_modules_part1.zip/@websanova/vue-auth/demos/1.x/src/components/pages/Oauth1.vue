<template>
    <div>
        <h1>Oauth1</h1>

        Not complete yet. This is mostly for Twitter since they don't support oauth2 yet...
    </div>
</template>