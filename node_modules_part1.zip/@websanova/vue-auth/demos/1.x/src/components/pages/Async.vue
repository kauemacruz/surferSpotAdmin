<template>
    <div>
        This is an async page.
    </div>
</template>