<template>
    <div>
        Product Info {{ $route.params.product_id }}
    </div>
</template>
