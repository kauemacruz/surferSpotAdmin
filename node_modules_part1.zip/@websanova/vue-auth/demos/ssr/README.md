# vue-auth-demo-ssr

Demo on how to run vue-auth with Server Side Rendering

Based on a stripped down version of [https://github.com/crisbal/vue-webpack-ssr-fully-featured](vue-webpack-ssr-fully-featured)

## Interesting parts

See [@crisbal's comment here](https://github.com/websanova/vue-auth/issues/120#issuecomment-316993838)

## How to run

`git clone`
`npm install`
`npm run dev`

### Building

`npm run build`
`npm run start`
