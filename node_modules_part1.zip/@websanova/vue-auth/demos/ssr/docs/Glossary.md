# Glossary

* **Client**, the browser that will run the WebApp
* **Server**, the process that will take care of pre-rendering the WebApp and serving it to the client
* **Server Side Rendering**, SSR, the process of pre-rendering the WebApp server-side, allowing support for people without JS, slow internet and/or devices, and search engines
