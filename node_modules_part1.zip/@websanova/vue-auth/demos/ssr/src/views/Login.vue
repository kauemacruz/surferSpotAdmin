<template lang="pug">
	.view--Login
		h1 Login Page
		h2 Maybe the token has expired?
		p  Lorem ipsum dolor sit amet, consectetur adipisicing elit. Natus, eum facilis ad, in minima officia quis porro accusamus rerum, inventore ipsum tempora, adipisci sapiente pariatur asperiores voluptatem harum voluptas nam.
</template>

<script>
export default {
	name: "Login",
	meta() {
		return {
			title: "Login",
			description: "This is the meta description for the login page"
		}
	}
}
</script>
