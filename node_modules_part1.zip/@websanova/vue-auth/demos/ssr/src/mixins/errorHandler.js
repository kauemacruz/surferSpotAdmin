export default {
	computed: {
		error() {
			return this.$store.state.error
		}
	}
}
