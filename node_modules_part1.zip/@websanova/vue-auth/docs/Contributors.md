# Contributors

* Thanks to [@crisbal](https://github.com/crisbal) for contributing [Vue SSR demo with vue-auth integration](https://github.com/crisbal/vue-webpack-ssr-fully-featured/tree/vue-auth-demo).

Thank you for everyone who has submitted bugs or fixes.

This is a new section so if you feel left out, just let me know!